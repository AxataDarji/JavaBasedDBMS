import java.io.*;
import java.util.Scanner;

/**
 * Main class for user authentication and data storage.
 */
public class JavaBasedDBMS implements ConstantCodes {

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        UserAuth currentUser = null;
        System.out.println("Welcome to CustomDB !");

        /**
        * Show options for user to choose
        */
        while (true) {
            System.out.println("1. Sign Up");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Select an option: ");
            int option = scanner.nextInt();
            scanner.nextLine();

            if (option == 1) {
                /**
                * Register the user
                */
                System.out.print("Enter a username: ");
                String username = scanner.nextLine();
                System.out.print("Enter a password: ");
                String password = scanner.nextLine();

                if (UserAuth.isUsernameTaken(username)) {
                    System.out.println("Username already exists. Please choose another one.");
                } else {
                    UserAuth newUser = new UserAuth(username, password);
                    newUser.generateCaptcha();
                    System.out.println("Your CAPTCHA: " + newUser.generateCaptcha());

                    System.out.print("Enter the CAPTCHA to complete registration: ");
                    String captchaResponse = scanner.nextLine();

                    if (newUser.verifyCaptchaResponse(captchaResponse)) {
                        try {
                            newUser.signUp();
                            System.out.println("Registration successful.");
                        } catch (IOException e) {
                            System.err.println("Error while saving user data.");
                        }
                    } else {
                        System.out.println("CAPTCHA verification failed.");
                    }
                }
            } 
            else if (option == 2) 
            {
                 /**
                * Login the user
                */
                System.out.print("Enter your username: ");
                String username = scanner.nextLine();
                System.out.print("Enter your password: ");
                String password = scanner.nextLine();

                try {
                    currentUser = UserInfoStorage.authenticateUser(username, password);
                    if (currentUser != null) {

                        currentUser.generateCaptcha();
                        System.out.println("Your CAPTCHA: " + currentUser.generateCaptcha());

                        System.out.print("Enter the CAPTCHA to complete login: ");
                        String captchaResponse = scanner.nextLine();

                        if (currentUser.verifyCaptchaResponse(captchaResponse)){
                            System.out.println("Login successful. Welcome, " + currentUser.getUsername() + "!");

                            String existingDB = checkIfDataBaseExists();

                            if (existingDB == null) {
                                System.out.print("Enter a name for your new database: ");
                                String existingDBName = scanner.nextLine();
                                createNewDatabase(existingDBName);
                                System.out.println("New database " + existingDBName + " created.");
                                existingDB = existingDBName;
                            } else {
                                String[] file_parts = existingDB.split("-");
                                System.out.println("Using existing database: " + file_parts[0]);
                                existingDB = file_parts[0];
                            }
                            runQueryLoop(currentUser, existingDB);
                        }
                        else {
                            System.out.println("CAPTCHA verification failed. Login aborted.");
                        }
                    } else {
                        System.out.println("Invalid username or password. Please try again.");
                    }
                } catch (IOException e) {
                    System.err.println("Error while authenticating user.");
                }
            }
            else if (option == 3) 
            {
                /**
                * Exit the MyJavaSQL
                */
                break;
            }
            else{
                System.out.println("Invalid Option");
            }
        }
    }

    /**
     * Runs a loop to accept user queries and execute them. Queries are terminated with a semicolon.
     *
     * @param userService The user to execute queries for.
     * @param db The name of the database.
     * @throws IOException If an I/O error occurs.
     */
    private static void runQueryLoop(UserAuth userService, String db) throws IOException {
        Scanner scanner = new Scanner(System.in);
        StringBuilder queryBuilder = new StringBuilder();

        System.out.print("Enter a query (terminated with ';' to exit enter \"EXIT;\"): \n");
        while (true) {
            System.out.print("\nquery> ");
            String line = scanner.nextLine();

            if (line.equalsIgnoreCase("EXIT;")) {
                break;
            }

            queryBuilder.append(line).append(" ");

            if (line.trim().endsWith(";")) {
                String query = queryBuilder.toString().trim();

                if(query.toLowerCase().contains("start transaction")){
                    Transaction txn = new Transaction(db, userService);
                    txn.startTransaction();
                    Scanner txn_scanner = new Scanner(System.in);
                    StringBuilder txn_queryBuilder = new StringBuilder();

                    boolean flag = true;
                    while (flag){
                        System.out.print("\nquery> ");
                        String txn_line = scanner.nextLine();
                        txn_queryBuilder.append(txn_line).append(" ");
                        if (txn_line.trim().endsWith(";")){
                            String txn_query = txn_queryBuilder.toString().trim();
                            if(txn_query.toLowerCase().contains("commit") || txn_query.toLowerCase().contains("end transaction")){
                                txn.performCommitStatement();

                                flag=false;
                                break;
                            }
                            else if(txn_query.toLowerCase().contains("rollback")){
                                txn.performRollbackStatement();
                            }
                            else {
                                txn.executeSQLQuery(txn_query);
                            }
                            txn_queryBuilder.setLength(0);
                        }
                    }

                }

                else{
                    query = query.replaceAll(";", "");
                    query = query + ";";
                    query = query.replaceAll(" +;", ";");
                    query = query.replaceAll("\\s+", " ");
                    query = query.trim();
                    String result = Query.executeQuery(query, userService, db);
                    System.out.println("Result: " + result);
                }
                queryBuilder.setLength(0);
            }
        }
    }

    /**
     * Checks if a database with the data file suffix exists in the current working directory.
     *
     * @return The name of the database if found; otherwise, null.
     */
    public static String checkIfDataBaseExists() {
        File directory = new File(FILES_PATH);
        File[] files = directory.listFiles();

        if (files != null) {
            for (File file : files) {
                if (file.isFile() && file.getName().endsWith(DATA_FILE_SUFFIX)) {
                    return file.getName();
                }
            }
        }
        return null;
    }

    /**
     * Creates a new database with the specified name by creating schema and data files.
     *
     * @param dbname The name of the new database.1
     * @return The name of the created database, or "NO DB created..." if the database couldn't be created.
     * @throws IOException If an I/O error occurs.
     */
    public static String createNewDatabase(String dbname) throws IOException {
        String schemaFileName = dbname + SCHEMA_FILE_SUFFIX;
        String dataFileName = dbname + DATA_FILE_SUFFIX;
        File schemaFile = new File(FILES_PATH, schemaFileName);
        File dataFile = new File(FILES_PATH, dataFileName);
        if (schemaFile.createNewFile() && dataFile.createNewFile()) {
            return dbname;
        }
        else
        {
            return "NO DB created.";
        }
    }
}
