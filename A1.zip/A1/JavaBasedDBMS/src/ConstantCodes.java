public interface ConstantCodes {

    public static final String FILES_PATH = "src/files/";
    public static final String DATA_FILE_SUFFIX = "-table-data.txt";
    public static final String COPY_DATA_FILE_SUFFIX = "-copy-table-data.txt";
    public static final String SCHEMA_FILE_SUFFIX = "-table-schema.txt";
    public static final String COPY_SCHEMA_FILE_SUFFIX = "-copy-table-schema.txt";
    public static final String USER_DATA_FILE = "src/files/registered_user_data.txt";
    public static final String USER_DELIMITER = "|";
    public static final String USER_ACTIVITY_LOG = "registered_user_activity.log";
    public static final String TRANSACTION_FLAG_SUFFIX = "_transaction_flag.txt";

}