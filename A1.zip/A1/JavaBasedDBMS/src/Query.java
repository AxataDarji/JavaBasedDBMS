import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A class for executing SQL queries based on user input.
 */
public class Query implements ConstantCodes{

    private static final Logger logger = Logger.getLogger("UserActivityLog");

    static {
        try {
            FileHandler fileHandler = new FileHandler( FILES_PATH + USER_ACTIVITY_LOG, true);
            fileHandler.setFormatter(new SimpleFormatter());
            logger.addHandler(fileHandler);
        }
        catch (IOException e) 
        {
            System.err.println("Error encountered ");
        }
    }

    /**
     * Executes the provided SQL query based on the query type.
     *
     * @param query The SQL query to execute.
     * @param user The user executing the query.
     * @return A message indicating the result of the query execution.
     * @throws IOException If an I/O error occurs.
     */
    public static String executeQuery(String query, UserAuth user, String databaseName) throws IOException {
        String result;

        /**
        * Identify the query type and perform actions accordingly.
        */
        if (query.endsWith(";")) {
            if (query.toLowerCase().startsWith("create table")) {
                //perform create query
                result = performCreateQuery(query, user, databaseName);
            } else if (query.toLowerCase().startsWith("select")) {
                //perform select query
                result = performSelectQuery(query, user, databaseName);
            } else if (query.toLowerCase().startsWith("insert into")) {
                //perform insert query
                result = performInsertQuery(query, user, databaseName);
            } else if (query.toLowerCase().startsWith("update")) {
                //perform update query
                 result = performUpdateQuery(query, user, databaseName);
            } else if (query.toLowerCase().startsWith("delete from")) {
                //perform delete query
                 result = performDeleteQuery(query, user, databaseName);
            } else {
                //Unknown query
                 result = "Unsupported query.";
            }
            String queryresult = logUserActivity(user, query, result);
            return queryresult;
        } else {
            //Query is not terminated properly
            return "Query must end with a semicolon;";
        }
    }

    /**
     * Handles the execution of a CREATE TABLE SQL query.
     *
     * @param query The SQL query to execute.
     * @param user The user executing the query.
     * @return A message indicating the result of the CREATE TABLE operation.
     */
    private static String performCreateQuery(String query, UserAuth user, String databaseName) throws FileNotFoundException {
        query = query.toLowerCase();
        if (!Validatior.isCreateTableQueryValid(query)) {
            return "Invalid CREATE TABLE query.";
        }

        String[] parts = query.split(" ");
        String tableName = parts[2];
        String columns = query.substring(query.indexOf('(') + 1, query.lastIndexOf(')'));

        if (Validatior.isTableExists(tableName, FILES_PATH + databaseName + SCHEMA_FILE_SUFFIX)) {
            return "Table already exists.";
        }

        String[] columnDefs = columns.split(",");
        StringBuilder schemaInfo = new StringBuilder();

        for (String columnDef : columnDefs) {
            String[] columnInfo = columnDef.trim().split(" ");
            if (columnInfo.length < 2) {
                return "Invalid column definition: " + columnDef;
            }

            String columnName = columnInfo[0];
            String dataType = columnInfo[1];

            boolean isPrimaryKey = false;
            boolean isNotNull = false;

            for (int i = 2; i < columnInfo.length; i++) {
                String option = columnInfo[i].toUpperCase();
                if (option.equals("PRIMARY")) {
                    isPrimaryKey = true;
                } else if (option.equals("NOT")) {
                    isNotNull = true;
                }
            }

            int varcharLength = -1;
            if (dataType.toUpperCase().contains("VARCHAR") && dataType.contains("(") && dataType.endsWith(")")){
                try {
                    varcharLength = Validatior.extractVarcharLength(dataType.toLowerCase());
                    System.out.println("\nVARCHAR : length = " + varcharLength);
                    dataType = "varchar";
                }
                catch (Exception e){
                    System.err.println("No length found for varchar");
                }
            }

            schemaInfo.append(columnName).append(":").append(dataType.toLowerCase()).append(":")
                    .append(isPrimaryKey).append(":").append(varcharLength).append(":")
                    .append(isNotNull).append(",");
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILES_PATH + databaseName + SCHEMA_FILE_SUFFIX, true))) {
            String delimiter = ";";

            writer.write(tableName + delimiter + schemaInfo.toString());
            writer.newLine();
        } 
        catch (IOException e) {
            return "Error while creating the table.";
        }
        return "Table created successfully.\n";
    }

    /**
     * Handles the execution of a SELECT SQL query.
     *
     * @param query The SQL query to execute.
     * @param user The user executing the query.
     * @return A message indicating the result of the SELECT operation.
     */
    private static String performSelectQuery(String query, UserAuth user, String databaseName) throws IOException {
        query = query.toLowerCase();
        if (!Validatior.isSelectQueryValid(query)) {
            return "Invalid SELECT query.";
        }

        String[] parts = query.split(" ");
        String tableName = null;

        for (int i = 0; i < parts.length; i++) {
            if (parts[i].equalsIgnoreCase("from") && i < parts.length - 1) {
                tableName = parts[i + 1];
                if (tableName.endsWith(";")) {
                    tableName = tableName.substring(0, tableName.length() - 1);
                }
                break;
            }
        }

        if (tableName == null) {
            return "Table name not found in the query.";
        }

        if (!Validatior.isTableExists(tableName, FILES_PATH + databaseName + SCHEMA_FILE_SUFFIX)) {
            return "Table does not exist.";
        }

        String schema = Validatior.getTableSchema(tableName, FILES_PATH + databaseName + SCHEMA_FILE_SUFFIX);
        String data = Validatior.getExistingData(tableName, FILES_PATH + databaseName + DATA_FILE_SUFFIX);

        boolean selectAll = query.contains("select *");
        String[] columns = null;

        if (!selectAll) {
            String columnsStr = query.substring(query.indexOf("select") + 6, query.indexOf("from")).trim();
            columns = columnsStr.split(",");
        }

        String whereClause = Validatior.extractWhereClause(query);
        Map<String, String> where_map = new HashMap<>();
        String where_key="";

        if(whereClause != null ){

            String[] WherekeyValuePairs = whereClause.split(", ");

            for (String keyValuePair : WherekeyValuePairs) {
                String[] where_parts = keyValuePair.split("\\s*=\\s*");

                if (where_parts.length == 2) {
                    String key = where_parts[0].trim();
                    where_key=where_parts[0].trim();
                    String value = where_parts[1].replaceAll("'", "").trim();
                    where_map.put(key, value);
                }
            }
        }

        String[] schemaColumns = schema.split(",");
        String[] dataEntries = data.split(",");

        Map<String, Integer> column_key = new HashMap<>();

        for (int i = 0; i < schemaColumns.length; i++) {
            String[] column_parts = schemaColumns[i].split(":");
            if (column_parts.length > 0) {
                String key = column_parts[0];
                column_key.put(key, i);
            }
        }

        if (selectAll) {
            for (String schemaColumn : schemaColumns) {
                String[] columnInfo = schemaColumn.split(":");
                System.out.print(columnInfo[0] + "\t");
            }
            System.out.println();
        } else {
            for (String column : columns) {
                System.out.print(column.trim() + "\t");
            }
            System.out.println();
        }

        List<String> parsedList = new ArrayList<>();
        for (String dataEntry : dataEntries) {
            StringBuilder str = new StringBuilder();
            for (int i = 0; i < dataEntry.length(); i++) {
                char character = dataEntry.charAt(i);

                if (character != ' ' && character != '(' && character != ')' && character != '\"'){
                    str.append(character);
                }
                if (i == dataEntry.length()-1){
                    parsedList.add(str.toString());
                }
            }

            if(parsedList.size() == schemaColumns.length){
                if(selectAll){
                    for (String element : parsedList) {
                        if(whereClause != null) {
                            if(where_map.get(where_key).equals(parsedList.get(column_key.get(where_key)))){
                                System.out.print(element.trim() + "\t");
                            }
                        }
                        else{
                            System.out.print(element.trim() + "\t");
                        }
                    }
                }
                else {
                    if(whereClause != null){
                        if(where_map.get(where_key).equals(parsedList.get(column_key.get(where_key)))){
                            for(String column : columns){
                                Integer index = column_key.get(column.trim());
                                String x = parsedList.get(index);
                                System.out.print(x + "\t");
                            }
                        }
                    }
                    else{
                        for(String column : columns){
                            Integer index = column_key.get(column.trim());
                            String x = parsedList.get(index);
                            System.out.print(x + "\t");
                        }
                    }
                }
                parsedList.clear();
                System.out.println();
            }
        }
        return "SELECT query executed successfully.";
    }


    /**
     * Handles the execution of an INSERT INTO SQL query.
     *
     * @param query The SQL query to execute.
     * @param user The user executing the query.
     * @return A message indicating the result of the INSERT INTO operation.
     */
    private static String performInsertQuery(String query, UserAuth user, String databaseName) throws IOException {
        query = query.toLowerCase();
        if (!Validatior.isInsertQueryValid(query)) {
            return "Invalid INSERT INTO query.";
        }

        String[] parts = query.split(" ");
        String tableName = parts[2];
        int valuesStartIndex = query.indexOf("values (") + "values (".length();
        String values = query.substring(valuesStartIndex, query.lastIndexOf(')'));

        String schemaFileName = FILES_PATH + databaseName + SCHEMA_FILE_SUFFIX;
        if (!Validatior.isTableExists(tableName, schemaFileName)) {
            return "Table does not exist.";
        }

        String schemaInfo = Validatior.getTableSchema(tableName, schemaFileName);


        if (schemaInfo == null) {
            return "Failed to rea table schema.";
        }

        if (schemaInfo.endsWith(",")) schemaInfo = schemaInfo.substring(0, schemaInfo.length() - 1);

        String[] columns = schemaInfo.split(",");
        String[] valueList = values.split(",");
        StringBuilder dataInfo = new StringBuilder();

        System.out.println("Columns" + " " + Arrays.toString(columns));
        System.out.println("Value" + " " + Arrays.toString(valueList));

        if (columns.length != valueList.length) {
            return "Column count doesn't match query value count.";
        }

        for (int i = 0; i < columns.length; i++) {
            String[] columnInfo = columns[i].split(":");
            String columnName = columnInfo[0];
            String dataType = columnInfo[1].toLowerCase();
            System.out.print(columnName);

            dataInfo.append(valueList[i]).append(",");
        }

        dataInfo.setLength(dataInfo.length() - 1);
        System.out.println(dataInfo.toString());

        var existingData = Validatior.getExistingData(tableName, FILES_PATH + databaseName + DATA_FILE_SUFFIX);
        var dataFileName = FILES_PATH + databaseName + DATA_FILE_SUFFIX;
        var tableData = new ArrayList<String>();
        var found = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(dataFileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] new_parts = line.split(";", 2);
                if (new_parts.length >= 1 && new_parts[0].trim().equals(tableName)) {
                    tableData.add(tableName + ";" + "{" + existingData + ", " + "(" + dataInfo.toString() + ")}");
                    found = true;
                } else {
                    tableData.add(line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error");
        }

        if (!found) {
            tableData.add(tableName + ";" + "{" + "(" + dataInfo.toString() + ")}");
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dataFileName, false))) {
            for (String line : tableData) {
                writer.write(line);
                writer.newLine();
            }
        }
        return "Values inserted successfully.";
    }

    /**
     * Handles the execution of an UPDATE SQL query.
     *
     * @param query The SQL query to execute.
     * @param user The user executing the query.
     * @return A message indicating the result of the UPDATE operation.
     */
    private static String performUpdateQuery(String query, UserAuth user, String databaseName) throws IOException {
        query = query.toLowerCase();
        if (!Validatior.isUpdateQueryValid(query)) {
            return "Invalid UPDATE query statement.";
        }

        String[] parts = query.split(" ");
        String tableName = null;
        /**
        * Check for table name from query
        */
        for (int i = 0; i < parts.length; i++) {
            if (parts[i].equalsIgnoreCase("update") && i < parts.length - 1) {
                tableName = parts[i + 1];
                if (tableName.endsWith(";")) {
                    tableName = tableName.substring(0, tableName.length() - 1);
                }
                break;
            }
        }

        if (tableName == null) {
            return "Table name is missing in the query.";
        }

        if (!Validatior.isTableExists(tableName, FILES_PATH + databaseName + SCHEMA_FILE_SUFFIX)) {
            return "Table does not exist in the database.";
        }

        String schema = Validatior.getTableSchema(tableName, FILES_PATH + databaseName + SCHEMA_FILE_SUFFIX);

        String setClause = Validatior.extractSetClause(query);
        String whereClause = Validatior.extractWhereClause(query);

        /**
        * Get set clause from query
        */
        Map<String, String> updateValues = Validatior.parseSetClause(setClause);
        boolean updateAll = true;
        if(whereClause != null){
            updateAll = false;
        }
        /**
        * Get existing data from database
        */
        String data = Validatior.getExistingData(tableName, FILES_PATH + databaseName + DATA_FILE_SUFFIX);
        String[] dataEntries = data.split(",");

        String[] schemaColumns = schema.split(",");

        Map<String, Integer> column_key = new HashMap<>();

        for (int i = 0; i < schemaColumns.length; i++) {
            String[] column_parts = schemaColumns[i].split(":");
            if (column_parts.length > 0) {
                String key = column_parts[0];
                column_key.put(key, i);
            }
        }

        List<List<String>> parent_data = new ArrayList<>();
        List<String> parsedList = new ArrayList<>();

        for (String dataEntry : dataEntries) {

            StringBuilder str = new StringBuilder();
            for (int i = 0; i < dataEntry.length(); i++) {
                char character = dataEntry.charAt(i);

                if (character != ' ' && character != '(' && character != ')' && character != '\"'){
                    str.append(character);
                }
                if (i == dataEntry.length()-1){
                    parsedList.add(str.toString());

                }
                if(parsedList.size() == schemaColumns.length){

                    parent_data.add(new ArrayList<>(parsedList));
                    parsedList.clear();
                }
            }
        }

        Map<String, String> set_map = new HashMap<>();
        String[] keyValuePairs = setClause.split(", ");

        for (String keyValuePair : keyValuePairs) {
            String[] set_parts = keyValuePair.split(" = ");

            if (set_parts.length == 2) {
                String key = set_parts[0].trim();
                String value = set_parts[1].replaceAll("'", "").trim();
                set_map.put(key, value);
            }
        }

        if(updateAll){
            for (List<String> innerList : parent_data){
                for (String key : set_map.keySet()) {
                    innerList.set(column_key.get(key),set_map.get(key));
                }
            }
        }

        else {
            String where_key="";
            Map<String, String> where_map = new HashMap<>();

            String[] WherekeyValuePairs = whereClause.split(", ");

            for (String keyValuePair : WherekeyValuePairs) {
                String[] where_parts = keyValuePair.split("\\s*=\\s*");

                if (where_parts.length == 2) {
                    String key = where_parts[0].trim();
                    where_key=where_parts[0].trim();
                    String value = where_parts[1].replaceAll("'", "").trim();
                    where_map.put(key, value);
                }
            }

            for (List<String> innerList : parent_data){
                for (String key : set_map.keySet()) {
                    if(innerList.get(column_key.get(where_key)).equals(where_map.get(where_key))){
                        innerList.set(column_key.get(key),set_map.get(key));
                    }

                }
            }
        }

        StringBuilder result = new StringBuilder();
        for (List<String> innerList : parent_data) {
            result.append("(");
            for (int i = 0; i < innerList.size(); i++) {
                result.append(innerList.get(i));
                if (i < innerList.size() - 1) {
                    result.append(", ");
                }
            }
            result.append("), ");
        }
        System.out.println(result.toString());
        if (result.length() > 0) {
            result.delete(result.length() - 2, result.length());
        }

        var dataFileName = FILES_PATH + databaseName + DATA_FILE_SUFFIX;
        var tableData = new ArrayList<String>();

        try (BufferedReader reader = new BufferedReader(new FileReader(dataFileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] new_parts = line.split(";", 2);
                if (new_parts.length >= 1 && new_parts[0].trim().equals(tableName)) {
                    tableData.add(tableName + ";" + "{" + result.toString() + "}");

                } else {
                    tableData.add(line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error");
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dataFileName, false))) {
            for (String line : tableData) {
                writer.write(line);
                writer.newLine();
            }
        }
        return "UPDATE statement processed successfully";
    }

    /**
     * Reads and parses data entries for the specified table from a data file.
     *
     * @param tableName     The name of the table to read data entries for.
     * @param dataFileName  The name of the data file to read from.
     * @return              A list of data entries for the specified table.
     * @throws IOException  If an I/O error occurs while reading the data file.
     */
    private static List<String> ReadDataEntries(String tableName, String dataFileName) throws IOException {
        List<String> dataEntries = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(dataFileName))) 
        {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(tableName + ";{") && line.endsWith("}")) {
                    String data = line.substring(line.indexOf("{") + 1, line.lastIndexOf("}"));
                    dataEntries.add(data);
                }
            }
        }
        return dataEntries;
    }

    /**
     * Handles the execution of a DELETE SQL query.
     *
     * @param query        The SQL query to execute.
     * @param user         The user executing the query.
     * @param databaseName The name of the database.
     * @return A message indicating the result of the DELETE operation.
     */
    private static String performDeleteQuery(String query, UserAuth user, String databaseName) throws IOException {
        query = query.toLowerCase();
        if (!Validatior.isDeleteQueryValid(query)) {
            return "Invalid DELETE query.";
        }

        String[] parts = query.split(" ");
        String tableName = null;

        for (int i = 0; i < parts.length; i++) {
            if (parts[i].equalsIgnoreCase("from") && i < parts.length - 1) {
                tableName = parts[i + 1];
                if (tableName.endsWith(";")) {
                    tableName = tableName.substring(0, tableName.length() - 1);
                }
                break;
            }
        }

        if (tableName == null) {
            return "Table name not found in the query.";
        }

        if (!Validatior.isTableExists(tableName, FILES_PATH + databaseName + SCHEMA_FILE_SUFFIX)) {
            return "Table does not exist in database.";
        }

        String whereClause = Validatior.extractWhereClause(query);
        Map<String, String> whereConditions = Validatior.parseWhereClause(whereClause);

        String where_key = whereConditions.keySet().iterator().next();


        String dataFileName = FILES_PATH + databaseName + DATA_FILE_SUFFIX;
        List<String> tableData = new ArrayList<>();
        boolean found = false;

        String schema = Validatior.getTableSchema(tableName, FILES_PATH + databaseName + SCHEMA_FILE_SUFFIX);

        String[] schemaColumns = schema.split(",");

        Map<String, Integer> column_key = new HashMap<>();

        for (int i = 0; i < schemaColumns.length; i++) {
            String[] column_parts = schemaColumns[i].split(":");
            if (column_parts.length > 0) {
                String key = column_parts[0];
                column_key.put(key, i);
            }
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(dataFileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] new_parts = line.split(";", 2);
                if (new_parts.length >= 1 && new_parts[0].trim().equals(tableName)) {
                    String data = new_parts[1].substring(1, new_parts[1].length() - 1);
                    System.out.println(data);
                    String[] dataEntries = data.split("\\), \\(");

                    List<String> newDataEntries = new ArrayList<>();
                    List<List<String>> entryList = new ArrayList<>();

                    for (String entry : dataEntries){
                        String[] sub_parts = entry.replace("(", "").replace(")", "").split(", ");
                        entryList.add(Arrays.asList(sub_parts));
                    }
                    System.out.println(entryList);

                    for (List<String> innerList : entryList) {
                        if(!innerList.get(column_key.get(where_key)).equals(whereConditions.get(where_key))){
                            String entry = "(" + String.join(", ", innerList) + ")";
                            newDataEntries.add(entry);
                        }
                        else {
                            found = true;
                        }
                    }

                    if (!newDataEntries.isEmpty()) {
                        tableData.add(tableName + ";" + "{" + String.join(", ", newDataEntries) + "}");
                    }
                } else {
                    tableData.add(line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error");
        }


        if (!found) {
            return "No matching rows found for performing DELETE operation.";
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dataFileName, false))) {
            for (String line : tableData) {
                writer.write(line);
                writer.newLine();
            }
        }

        return "DELETE statement processed successfully";
    }

    /**
     * Logs user activity, including the query, timestamp, and query result.
     *
     * @param user   The user performing the query.
     * @param query  The SQL query executed.
     * @param result The result of the query execution.
     */
    private static String logUserActivity(UserAuth user, String query, String result) {

        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        String logMessage = String.format("Timestamp: %s, User: %s, Query: %s, Result: %s", timestamp, user.getUsername(), query, result);
        logger.info(logMessage);
        return result;
    }

}
