import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Random;

/**
 * Represents a user for authentication.
 */
class UserAuth {
    private String username;
    private String passwordHash;
    private String correctCaptchaResponse;

    /**
     * Initializes a new user with a username and hashed password.
     *
     * @param username The username.
     * @param password The plaintext password.
     */
    public UserAuth(String username, String password) {
        this.username = username;
        this.passwordHash = hashPassword(password);
    }

    /**
     * Initializes a new user with a username and password hash.
     *
     * @param username The username.
     * @param password The password hash.
     * @param validate If true, the password hash is validated; if false, it's used as is.
     */
    public UserAuth(String username, String password, Boolean validate) {
        this.username = username;
        if (validate) {
            this.passwordHash = password;
        }
    }

    /**
     * Authenticates the user using the entered password.
     *
     * @param enteredPassword The plaintext password entered by the user.
     * @return True if authentication is successful; otherwise, false.
     */
    public boolean authenticateUser(String enteredPassword) {
        return passwordHash.equals(hashPassword(enteredPassword));
    }

    /**
     * Generates a CAPTCHA for user authentication.
     *
     * @return A CAPTCHA string.
     */
    public String generateCaptcha() {
        String captcha;
        Random rand = new Random();
        int num1 = rand.nextInt(10);
        int num2 = rand.nextInt(10);

        captcha = num1 + " - " + num2 + " = ?";
        correctCaptchaResponse = String.valueOf(num1 - num2);
        return captcha;
    }

    /**
     * Verifies the entered CAPTCHA.
     *
     * @param captchaResponse The user's CAPTCHA input.
     * @return True if the CAPTCHA is verified; otherwise, false.
     */
    public boolean verifyCaptchaResponse(String captchaResponse) {
        return correctCaptchaResponse.equals(captchaResponse);
    }

    /**
     * Writes user data to the data file.
     *
     * @throws IOException If an I/O error occurs.
     */
    public void signUp() throws IOException {
        UserInfoStorage.writeUserToFile(this);
    }

    /**
     * Checks if a username is already taken.
     *
     * @param username The username to check.
     * @return True if the username is taken; otherwise, false.
     * @throws IOException If an I/O error occurs.
     */
    public static boolean isUsernameTaken(String username) throws IOException {
        List<UserAuth> users = UserInfoStorage.readUsersFromFile();
        for (UserAuth user : users) {
            if (user.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Hashes a password using the MD5 algorithm.
     *
     * @param password The password to be hashed.
     * @return The hashed password as a hexadecimal string.
     * @throws RuntimeException If the MD5 algorithm is not available on the system.
     */
    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] bytes = md.digest(password.getBytes());
            StringBuilder result = new StringBuilder();
            for (byte aByte : bytes) {
                result.append(Integer.toString((aByte & 0xff) + 0x100, 16).substring(1));
            }
            return result.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("MD5 algorithm not availabe.", e);
        }
    }

    /**
     * Gets the username.
     *
     * @return The username.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Gets the password hash.
     *
     * @return The password hash.
     */
    public String getPasswordHash() {
        return passwordHash;
    }
}
