import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Manages data storage operations, including reading and writing user data to text files.
 */
class UserInfoStorage implements ConstantCodes {

    /**
     * Writes user data to the data file.
     *
     * @param user The user to write to the file.
     * @throws IOException If an I/O error occurs.
     */
    public static void writeUserToFile(UserAuth user) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(USER_DATA_FILE, true))) {
            writer.println(user.getUsername() + USER_DELIMITER + user.getPasswordHash());
        }
    }

    /**
     * Authenticates a user based on the entered username and password.
     *
     * @param username The entered username.
     * @param password The entered password.
     * @return The authenticated user or null if authentication fails.
     * @throws IOException If an I/O error occurs.
     */
    public static UserAuth authenticateUser(String username, String password) throws IOException {
        try {
            List<UserAuth> users = readUsersFromFile();
            for (UserAuth user : users) {
                if (user.getUsername().equals(username) && user.authenticateUser(password)) {
                    return user;
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Reads user data from the data file.
     *
     * @return A list of User objects.
     * @throws IOException If an I/O error occurs.
     */
    public static List<UserAuth> readUsersFromFile() throws IOException {
        List<UserAuth> users = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(USER_DATA_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");

                if (parts.length == 2) {
                    UserAuth user = new UserAuth(parts[0], parts[1], true);
                    users.add(user);
                }
            }
        }
        return users;
    }
}
