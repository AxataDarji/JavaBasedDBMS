import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validatior implements ConstantCodes{


    /**
     * Validates if the provided SQL query is a valid SELECT query.
     *
     * @param query The SELECT query to validate.
     * @return True if the query is valid; false otherwise.
     */
    public static boolean isSelectQueryValid(String query) {
        String regex = "select\\s+(\\*|\\w+(\\s*,\\s*\\w+)*)\\s+from\\s+\\w+\\s*(?:where\\s+.+)?;";
        return query.matches(regex);
    }

    /**
     * Validates if the provided SQL query is a valid INSERT query.
     *
     * @param query The INSERT query to validate.
     * @return True if the query is valid; false otherwise.
     */
    public static boolean isInsertQueryValid(String query) {
        String regex = "insert into\\s+\\w+\\s*values\\s*\\([^)]*\\);";
        return query.matches(regex);
    }

    /**
     * Retrieves the existing data for a given table name from a data file.
     *
     * @param tableName     The name of the table.
     * @param dataFileName  The name of the data file.
     * @return The existing data for the specified table.
     */
    public static String getExistingData(String tableName, String dataFileName){
        try (BufferedReader reader = new BufferedReader(new FileReader(dataFileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";", 2);
                if (parts.length >= 1 && parts[0].trim().equals(tableName)) {
                    String data = parts[1].trim();
                    int startIndex = data.indexOf('{');
                    int endIndex = data.lastIndexOf('}');
                    if (startIndex != -1 && endIndex != -1) {
                        return data.substring(startIndex + 1, endIndex);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Data file not found");
        }
        return null;
    }

    /**
     * Retrieves the schema for a given table name from a schema file.
     *
     * @param tableName     The name of the table.
     * @param schemaFileName The name of the schema file.
     * @return The schema for the specified table.
     * @throws FileNotFoundException If the schema file is not found.
     */
    public static String getTableSchema(String tableName, String schemaFileName) throws FileNotFoundException {
        try (BufferedReader reader = new BufferedReader(new FileReader(schemaFileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";", 2);
                if (parts.length >= 1 && parts[0].trim().equals(tableName)) {
                    return parts[1].trim();
                }
            }
        } catch (IOException e) {
            System.err.println("Schema file not found");
        }
        return null;
    }

    /**
     * Extracts the WHERE clause from a SQL query.
     *
     * @param query The SQL query.
     * @return The WHERE clause or null if not found.
     */
    public static String extractWhereClause(String query) {
        query= query.toLowerCase();
        if (query.endsWith(";")) {
            query = query.substring(0, query.length() - 1);
        }
        int whereStart = query.indexOf("where");
        if (whereStart == -1) {
            return null;
        }

        return query.substring(whereStart + 5).trim();
    }

    /**
     * Parses the SET clause of an UPDATE query and creates a map of column-value pairs.
     *
     * @param setClause The SET clause of the UPDATE query.
     * @return A map of column-value pairs.
     */
    public static Map<String, String> parseSetClause(String setClause) {
        Map<String, String> setValues = new HashMap<>();
        String[] keyValuePairs = setClause.split(",");
        for (String pair : keyValuePairs) {
            String[] keyValue = pair.split("=");
            if (keyValue.length == 2) {
                String column = keyValue[0].trim();
                String value = keyValue[1].trim();
                setValues.put(column, value);
            }
        }
        return setValues;
    }


    /**
     * Extracts the SET clause from an SQL query.
     *
     * @param query The SQL query.
     * @return The SET clause or null if not found.
     */
    public static String extractSetClause(String query) {
        query= query.toLowerCase();
        if (query.endsWith(";")) {
            query = query.substring(0, query.length() - 1);
        }
        int setStart = query.indexOf("set");
        if (setStart == -1) {
            return null;
        }

        int setEnd = query.indexOf("where", setStart);
        if (setEnd == -1) {
            return query.substring(setStart + 3).trim();
        } else {
            return query.substring(setStart + 3, setEnd).trim();
        }
    }

    /**
     * Validates if the provided SQL query is a valid UPDATE query.
     *
     * @param query The UPDATE query to validate.
     * @return True if the query is valid; false otherwise.
     */
    public static boolean isUpdateQueryValid(String query) {
        query = query.toLowerCase();

        if (!query.startsWith("update") || !query.contains("set")) {
            return false;
        }

        if (!query.contains("where") && query.contains("set")) {
            return true;
        }

        if (query.indexOf("set") > query.indexOf("where")) {
            return false;
        }

        return true;
    }

    /**
     * Validates if the provided SQL query is a valid DELETE query.
     *
     * @param query The DELETE query to validate.
     * @return True if the query is valid; false otherwise.
     */
    public static boolean isDeleteQueryValid(String query) {
        String regex = "delete\\s+from\\s+\\w+\\s+where\\s+.+;";
        return query.matches(regex);
    }

    /**
     * Parses the WHERE condition and returns a map of key-value pairs.
     *
     * @param whereClause The WHERE clause from the SQL query.
     * @return A map of key-value pairs in the WHERE condition.
     */
    public static Map<String, String> parseWhereClause(String whereClause) {
        Map<String, String> whereConditions = new HashMap<>();
        if (whereClause != null) {
            String[] logicalOperators = whereClause.split("\\b(AND|OR)\\b");

            for (String operator : logicalOperators) {
                String[] keyValuePair = operator.split("\\s*=\\s*", 2);

                if (keyValuePair.length == 2) {
                    String key = keyValuePair[0].trim();
                    String value = keyValuePair[1].replaceAll("'", "").trim();
                    whereConditions.put(key, value);
                }
            }
        }
        return whereConditions;
    }

    /**
     * Checks if the provided CREATE TABLE query is valid using regex.
     *
     * @param query The SQL query to check.
     * @return True if the query is valid; otherwise, false.
     */
    public static boolean isCreateTableQueryValid(String query) {
        String regex = "create table\\s+\\w+\\s*\\((\\s*\\w+\\s+\\w+\\s*(?:\\(\\d+\\))?\\s*(?:primary key)?\\s*(?:not null)?\\s*,?\\s*)+\\);";
        return query.matches(regex);
    }

    /**
     * Checks if a table exists in a schema file.
     *
     * @param tableName     The name of the table.
     * @param schemaFileName The name of the schema file.
     * @return True if the table exists; false otherwise.
     * @throws FileNotFoundException If the schema file is not found.
     */
    public static boolean isTableExists(String tableName, String schemaFileName) throws FileNotFoundException {
        try (BufferedReader reader = new BufferedReader(new FileReader(schemaFileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";", 2);

                if (parts.length >= 1 && parts[0].trim().equals(tableName)) {
                    return true;
                }
            }
        } catch (IOException e) {
            System.err.println("File does not exist");
        }

        return false;
    }

    /**
     * Extracts the length of a VARCHAR column type.
     *
     * @param varchar The VARCHAR column type.
     * @return The length of the VARCHAR column.
     */
    public static int extractVarcharLength(String varchar){
        String pattern = "varchar\\((\\d+)\\)";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(varchar);

        if (m.find()) {
            String numberStr = m.group(1);
            return Integer.parseInt(numberStr);
        } else {
            System.out.println("No match found.");
        }
        return -1;
    }

}
