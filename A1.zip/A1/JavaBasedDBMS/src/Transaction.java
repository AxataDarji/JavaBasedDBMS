import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * The Transaction class handles database transactions, including beginning, committing, and rolling back transactions.
 * It also provides methods to execute SQL queries within a transaction.
 *
 */
class Transaction implements ConstantCodes{

    private UserAuth userService;
    private String databaseName;
    private String schemafileName;
    private String dataFileName;
    private List<String> transactionLog = new ArrayList<>();
    private boolean inTransaction = false;

    /**
     * Constructor for the Transaction class.
     *
     * @param databaseName The name of the database.
     * @param userService The userService performing the transaction.
     */
    public Transaction(String databaseName, UserAuth userService) {
        this.userService = userService;
        this.databaseName = databaseName;
        this.dataFileName = FILES_PATH + databaseName + DATA_FILE_SUFFIX;
        this.schemafileName = FILES_PATH + databaseName + SCHEMA_FILE_SUFFIX;
    }

    /**
     * Checks if a transaction is already in progress.
     *
     * @return True if a transaction is in progress; false otherwise.
     */
    private boolean isTransactionInProgress() {
        File transactionFlagFile = new File(FILES_PATH + databaseName + TRANSACTION_FLAG_SUFFIX);
        return transactionFlagFile.exists();
    }

    /**
     * Begins a transaction. Creates a copy of data and schema files.
     */
    public void startTransaction() {
        if (inTransaction) {
            System.out.println("Transaction is already in progress.");
            return;
        }

        if (isTransactionInProgress()) {
            System.out.println("Another transaction is already in progress.");
            return;
        }

        inTransaction = true;
        transactionLog.clear();

        createTransactionFlagFile();

        copyDataFile(FILES_PATH + databaseName + "_copy");
        copySchemaFile(FILES_PATH + databaseName + "_copy");
    }

    /**
     * Commits the transaction, applying changes from the transaction log.
     * Copies schema and data files from the copy.
     */
    public void performCommitStatement() {
        if (!inTransaction) {
            System.out.println("No active transaction to commit.");
            return;
        }

        transactionLog.add("COMMIT;");

        copySchemaFileFromDummy(FILES_PATH + databaseName + "_copy");
        copyDataFileFromDummy(FILES_PATH + databaseName + "_copy");

        removeDummyFile();
        removeCopySchemaFile();

        removeTransactionFlagFile();

        saveTransactionLog();

        inTransaction = false;
        transactionLog.clear();
    }

    /**
     * Rolls back the transaction. Reverts schema and data files to the copy.
     */
    public void performRollbackStatement() {
        if (!inTransaction) {
            System.out.println("No active transaction to rollback.");
            return;
        }

        transactionLog.add("ROLLBACK;");

        removeDummyFile();
        removeCopySchemaFile();

        copyDataFile(FILES_PATH + databaseName + "_copy");
        copySchemaFile(FILES_PATH + databaseName + "_copy");

        inTransaction = true;
    }

    /**
     * Saves the transaction log with a timestamp to a file.
     */
    private void saveTransactionLog() {
        String logFileName = "transactionLog.txt";

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String timestamp = sdf.format(new Date());

        try (PrintWriter writer = new PrintWriter(new FileWriter(logFileName, true))) {
            writer.println("Transaction Log Timestamp: " + timestamp);

            for (String entry : transactionLog) {
                writer.println(entry);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Creates a transaction flag file to indicate an active transaction.
     */
    private void createTransactionFlagFile() {
        try {
            File transactionFlagFile = new File(FILES_PATH + databaseName + TRANSACTION_FLAG_SUFFIX);
            if (transactionFlagFile.createNewFile()) {
                System.out.println("Transaction flag file created.");
            } else {
                System.out.println("Failed to create transaction flag file.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Removes the transaction flag file to end the transaction.
     */
    private void removeTransactionFlagFile() {
        File transactionFlagFile = new File(FILES_PATH + databaseName + TRANSACTION_FLAG_SUFFIX);
        if (transactionFlagFile.exists() && transactionFlagFile.delete()) {
            System.out.println("Transaction flag file deleted.");
        }
    }

    /**
     * Executes an SQL query within a transaction and logs it.
     *
     * @param query The SQL query to execute.
     * @throws IOException If an I/O error occurs during query execution.
     */
    public void executeSQLQuery(String query) throws IOException {
        if (inTransaction) {
            transactionLog.add(query);
            System.out.println(executeQuery(query));
        } else {
            System.out.println("No Transaction in progress");
        }
    }

    /**
     * Copies data from the main data file to a dummy data file.
     *
     * @param copyFileName The name of the dummy data file.
     */
    private void copyDataFile(String dummyFileName) {
        try (FileReader reader = new FileReader(dataFileName);
             FileWriter writer = new FileWriter(dummyFileName + DATA_FILE_SUFFIX)) {
            int c;
            while ((c = reader.read()) != -1) {
                writer.write(c);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Copies data from a dummy data file to the main data file.
     *
     * @param copyFileName The name of the dummy data file.
     */
    private void copyDataFileFromDummy(String dummyFileName) {
        try (FileReader reader = new FileReader(dummyFileName + DATA_FILE_SUFFIX);
             FileWriter writer = new FileWriter(dataFileName)) {
            int c;
            while ((c = reader.read()) != -1) {
                writer.write(c);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Copies schema from a dummy schema file to the main schema file.
     *
     * @param copyFileName The name of the dummy schema file.
     */
    private void copySchemaFileFromDummy(String dummyFileName) {
        try (FileReader reader = new FileReader(dummyFileName + SCHEMA_FILE_SUFFIX);
             FileWriter writer = new FileWriter(schemafileName)) {
            int c;
            while ((c = reader.read()) != -1) {
                writer.write(c);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Copies schema from the main schema file to a dummy schema file.
     *
     * @param copyFileName The name of the dummy schema file.
     */
    private void copySchemaFile(String copyFileName) {
        try (FileReader reader = new FileReader(schemafileName);
             FileWriter writer = new FileWriter(copyFileName + SCHEMA_FILE_SUFFIX)) {
            int c;
            while ((c = reader.read()) != -1) {
                writer.write(c);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Removes the copy data file.
     */
    private void removeDummyFile() {
        File copyFile = new File(FILES_PATH + databaseName + COPY_DATA_FILE_SUFFIX);
        if (copyFile.exists() && copyFile.delete()) {
            System.out.println("Copy file deleted.");
        }
    }

    /**
     * Removes the copy schema file.
     */
    private void removeCopySchemaFile() {
        File copyFile = new File(FILES_PATH + databaseName + COPY_SCHEMA_FILE_SUFFIX);
        if (copyFile.exists() && copyFile.delete()) {
            System.out.println("Copy file deleted.");
        }
    }

    /**
     * Executes an SQL query, removing semicolons and formatting the query.
     *
     * @param query The SQL query to execute.
     * @return The result of executing the query.
     * @throws IOException If an I/O error occurs during query execution.
     */
    private String executeQuery(String query) throws IOException {
        System.out.println("Executing query: " + query);

        query = query.replaceAll(";", "");
        query = query + ";";
        query = query.replaceAll(" +;", ";");
        query = query.replaceAll("\\s+", " ");
        query = query.trim();

        String result = Query.executeQuery(query, userService, databaseName + "_copy");
        return result;
    }

}